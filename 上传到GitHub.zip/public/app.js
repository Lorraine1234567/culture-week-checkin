'use strict';

/* ================= 状态 ================= */
const COLORS = ['red', 'green', 'purple', 'yellow'];
const COLOR_LABEL = { red: '红点', green: '绿点', purple: '紫点', yellow: '黄点' };
const ROW_LIMIT = 400;

const state = {
  hash: '',
  people: [],
  stats: null,
  sheets: [],
  fileName: '',
  filePath: '',
  updatedAt: null,
  online: false,
  tab: 'all',
  q: '',
  filter: 'all',
  sortKey: 'id',
  sortDir: 1,
  batchIds: [],
  batchRows: null,
  batchSummary: null,
  busy: false,
};

/* ================= 工具 ================= */
const $ = (id) => document.getElementById(id);

function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function toast(msg) {
  const el = $('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove('show'), 2200);
}

function fmtTime(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  if (isNaN(d)) return '—';
  const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

function splitTokens(text) {
  return String(text || '')
    .split(/[\s,，、;；|]+/)
    .map((t) => t.replace(/^["']|["']$/g, '').trim())
    .filter(Boolean);
}

function dot(color, on, small) {
  const cls = 'dot' + (small ? ' sm' : '') + (on ? ' on ' + color : ' off');
  return `<span class="${cls}" title="${COLOR_LABEL[color]}${on ? '已获得' : '未获得'}"></span>`;
}

/* ================= 数据请求 ================= */
async function fetchData(silent) {
  const url = '/api/data' + (state.hash ? '?since=' + encodeURIComponent(state.hash) : '');
  try {
    const res = await fetch(url, { cache: 'no-store' });
    if (res.status === 401) { location.replace('/login'); return; }
    const data = await res.json();

    if (!data.ok) {
      state.online = false;
      showBanner(data.error || '数据读取失败', true);
      setStatus(false);
      return;
    }

    state.online = true;

    if (data.changed === false) {
      setStatus(true);
      if (data.error) showBanner(data.error, true);
      else hideBanner();
      return;
    }

    const first = !state.hash;
    state.hash = data.hash;
    state.people = data.people || [];
    state.stats = data.stats || { total: 0, colors: {}, dots: 0, dist: {} };
    state.sheets = data.sheets || [];
    state.fileName = data.fileName || '';
    state.filePath = data.filePath || '';
    state.updatedAt = data.updatedAt;

    hideBanner();
    if (data.error) showBanner(data.error, true);
    else if (data.warnings && data.warnings.length) showBanner(data.warnings.join('；'), false);

    renderAll();

    if (!first && !silent) {
      toast('检测到 Excel 变化，已自动同步');
      if (state.batchIds.length) runQuery(true);
    }
  } catch (e) {
    state.online = false;
    setStatus(false);
    showBanner('无法连接本地服务，请确认「启动网站.bat」窗口仍在运行', true);
  }
}

function setStatus(ok) {
  const pill = $('livePill');
  pill.classList.toggle('err', !ok);
  $('statusText').textContent = ok ? '实时同步' : '连接中断';
  $('updateTime').textContent = state.updatedAt ? '更新于 ' + fmtTime(state.updatedAt) : '';
}

function showBanner(text, isErr) {
  const b = $('banner');
  b.hidden = false;
  b.className = 'banner' + (isErr ? '' : ' warn');
  b.textContent = text;
}
function hideBanner() { $('banner').hidden = true; }

/* ================= 渲染 ================= */
function renderAll() {
  renderStats();
  renderTable();
  renderMeta();
}

function renderStats() {
  const s = state.stats || { colors: {}, total: 0, dots: 0 };
  $('statTotal').textContent = s.total;
  $('statDots').textContent = `共 ${s.dots} 个点 · 人均 ${s.total ? (s.dots / s.total).toFixed(2) : '0.00'}`;
  $('statRed').textContent = s.colors.red || 0;
  $('statGreen').textContent = s.colors.green || 0;
  $('statPurple').textContent = s.colors.purple || 0;
  $('statYellow').textContent = s.colors.yellow || 0;
}

function renderMeta() {
  $('fileName').textContent = state.fileName || '—';
  const used = state.sheets.filter((s) => s.used);
  const detail = used.map((s) => `${s.name} ${s.rows}条`).join(' · ');
  $('footInfo').textContent = `数据源 ${state.fileName}${detail ? '（' + detail + '）' : ''}`;
  if (state.updatedAt) $('updateTime').textContent = '更新于 ' + fmtTime(state.updatedAt);
}

function filteredPeople() {
  const q = state.q.trim().toLowerCase();
  let list = state.people.filter((p) => {
    if (q) {
      const hay = (p.id + ' ' + p.name).toLowerCase();
      if (!hay.includes(q)) return false;
    }
    switch (state.filter) {
      case 'all': return true;
      case 'full': return p.count === 4;
      case 'zero': return p.count === 0;
      default: return !!p.colors[state.filter];
    }
  });

  const dir = state.sortDir;
  const key = state.sortKey;
  list = list.slice().sort((a, b) => {
    if (key === 'count') return (a.count - b.count) * dir || a.id.localeCompare(b.id);
    if (key === 'name') return a.name.localeCompare(b.name, 'zh-CN') * dir;
    return a.id.localeCompare(b.id, 'zh-CN', { numeric: true }) * dir;
  });
  return list;
}

function renderTable() {
  const list = filteredPeople();
  const shown = list.slice(0, ROW_LIMIT);

  const rows = shown.map((p) => {
    const src = p.sheets && p.sheets.length ? p.sheets.join('、') : '—';
    const cls = p.count === 4 ? 'count-badge full' : p.count === 0 ? 'count-badge zero' : 'count-badge';
    return `<tr>
      <td class="mono id-cell">${esc(p.id) || '—'}</td>
      <td class="name-cell">${esc(p.name) || '—'}</td>
      <td><div class="dot-cell">${dot('red', p.colors.red)}</div></td>
      <td><div class="dot-cell">${dot('green', p.colors.green)}</div></td>
      <td><div class="dot-cell">${dot('purple', p.colors.purple)}</div></td>
      <td><div class="dot-cell">${dot('yellow', p.colors.yellow)}</div></td>
      <td class="center"><span class="${cls}">${p.count}</span></td>
      <td class="src-cell">${esc(src)}</td>
    </tr>`;
  });

  if (!rows.length) {
    $('peopleBody').innerHTML = `<tr><td colspan="8" style="text-align:center;padding:44px;color:#8b93a3;">${
      state.people.length ? '没有符合条件的人员' : '暂无数据，请检查 Excel 是否有内容'
    }</td></tr>`;
  } else {
    $('peopleBody').innerHTML = rows.join('');
  }

  const dist = state.stats && state.stats.dist ? state.stats.dist : {};
  const parts = [0, 1, 2, 3, 4].map((n) => `${n}点 ${dist[n] || 0}人`);
  $('tableFoot').innerHTML =
    `共 <b>${list.length}</b> 人${list.length !== state.people.length ? `（筛选自 ${state.people.length} 人）` : ''}` +
    (list.length > ROW_LIMIT ? ` · 仅显示前 ${ROW_LIMIT} 条，请用搜索缩小范围` : '') +
    ` · 分布：${parts.join(' / ')}`;

  // 排序箭头
  document.querySelectorAll('th.sortable').forEach((th) => {
    th.classList.remove('sorted-asc', 'sorted-desc');
    if (th.dataset.sort === state.sortKey) {
      th.classList.add(state.sortDir > 0 ? 'sorted-asc' : 'sorted-desc');
    }
  });
}

/* ================= 批量查询 ================= */
async function runQuery(silent) {
  const ids = splitTokens($('batchText').value);
  if (!ids.length) {
    if (!silent) toast('请先粘贴或导入工号');
    return;
  }
  state.batchIds = ids;
  if (!silent) {
    state.busy = true;
    $('queryBtn').disabled = true;
    $('queryBtn').textContent = '查询中…';
  }
  try {
    const res = await fetch('/api/query', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids }),
    });
    if (res.status === 401) { location.replace('/login'); return; }
    const data = await res.json();
    if (!data.ok) { toast(data.error || '查询失败'); return; }
    state.batchRows = data.rows;
    state.batchSummary = data.summary;
    renderBatch();
  } catch (e) {
    toast('查询失败：' + e.message);
  } finally {
    state.busy = false;
    $('queryBtn').disabled = false;
    $('queryBtn').innerHTML = `<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"></circle><path d="M20 20l-3.5-3.5"></path></svg>开始查询`;
  }
}

function renderBatch() {
  const rows = state.batchRows || [];
  const s = state.batchSummary || {};
  const has = rows.length > 0;
  $('batchResult').hidden = !has;
  $('batchEmpty').hidden = has;
  if (!has) return;

  $('miniStats').innerHTML = [
    `<span class="mini">导入 <b>${s.input || 0}</b></span>`,
    `<span class="mini">去重后 <b>${s.unique || 0}</b></span>`,
    s.duplicate ? `<span class="mini">重复剔除 <b>${s.duplicate}</b></span>` : '',
    `<span class="mini ok">已找到 <b>${s.found || 0}</b></span>`,
    `<span class="mini bad">未找到 <b>${s.notFound || 0}</b></span>`,
    `<span class="mini">红 <b>${(s.colors && s.colors.red) || 0}</b></span>`,
    `<span class="mini">绿 <b>${(s.colors && s.colors.green) || 0}</b></span>`,
    `<span class="mini">紫 <b>${(s.colors && s.colors.purple) || 0}</b></span>`,
    `<span class="mini">黄 <b>${(s.colors && s.colors.yellow) || 0}</b></span>`,
  ].join('');

  $('resultBody').innerHTML = rows.map((r) => {
    const cls = r.count === 4 ? 'count-badge full' : r.count === 0 ? 'count-badge zero' : 'count-badge';
    const status = r.found
      ? `<span class="tag-found">已找到${r.matchedBy === '姓名' ? '（按姓名）' : ''}</span>`
      : `<span class="tag-miss">未找到</span>`;
    return `<tr>
      <td class="mono id-cell">${esc(r.id) || '—'}</td>
      <td class="name-cell">${esc(r.name) || '—'}</td>
      <td><div class="dot-cell">${dot('red', r.colors.red)}</div></td>
      <td><div class="dot-cell">${dot('green', r.colors.green)}</div></td>
      <td><div class="dot-cell">${dot('purple', r.colors.purple)}</div></td>
      <td><div class="dot-cell">${dot('yellow', r.colors.yellow)}</div></td>
      <td class="center"><span class="${cls}">${r.count}</span></td>
      <td class="src-cell">${status}</td>
    </tr>`;
  }).join('');
}

async function exportExcel() {
  const ids = state.batchIds.length ? state.batchIds : splitTokens($('batchText').value);
  if (!ids.length) { toast('请先导入工号'); return; }
  const btn = $('exportBtn');
  const old = btn.innerHTML;
  btn.disabled = true;
  btn.textContent = '正在生成…';
  try {
    const res = await fetch('/api/export', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids }),
    });
    if (!res.ok) {
      if (res.status === 401) { location.replace('/login'); return; }
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || '导出失败');
    }
    const blob = await res.blob();
    const cd = res.headers.get('Content-Disposition') || '';
    let name = '查询结果.xlsx';
    const m = /filename\*=UTF-8''([^;]+)/i.exec(cd);
    if (m) { try { name = decodeURIComponent(m[1]); } catch (_) {} }

    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    toast('已导出 ' + name);
  } catch (e) {
    toast('导出失败：' + e.message);
  } finally {
    btn.disabled = false;
    btn.innerHTML = old;
  }
}

function copyResult() {
  const rows = state.batchRows || [];
  if (!rows.length) return;
  const head = ['工号', '姓名', '红点', '绿点', '紫点', '黄点', '点数合计', '匹配状态'];
  const lines = [head.join('\t')];
  for (const r of rows) {
    lines.push([r.id, r.name, r.colors.red, r.colors.green, r.colors.purple, r.colors.yellow, r.count, r.found ? '已找到' : '未找到'].join('\t'));
  }
  const text = lines.join('\n');
  const done = () => toast('已复制，可直接粘贴到 Excel');
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopy(text, done));
  } else {
    fallbackCopy(text, done);
  }
}

function fallbackCopy(text, cb) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.position = 'fixed';
  ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); cb(); } catch (_) { toast('复制失败，请手动选择'); }
  ta.remove();
}

/* ================= 文件导入 ================= */
function handleFile(file) {
  if (!file) return;
  const lower = file.name.toLowerCase();
  if (lower.endsWith('.xls')) {
    toast('请先用 Excel 将 .xls 另存为 .xlsx 再导入');
    return;
  }
  const reader = new FileReader();
  reader.onload = async () => {
    try {
      if (lower.endsWith('.csv') || lower.endsWith('.txt')) {
        const text = String(reader.result || '');
        appendTokens(splitTokens(text.replace(/^\uFEFF/, '')));
      } else {
        const b64 = String(reader.result || '').split(',')[1] || '';
        const res = await fetch('/api/extract', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: file.name, base64: b64 }),
        });
        const data = await res.json();
        if (!data.ok) { toast(data.error || '解析文件失败'); return; }
        if (!data.tokens.length) { toast('文件里没有识别到工号'); return; }
        appendTokens(data.tokens);
      }
    } catch (e) {
      toast('导入失败：' + e.message);
    }
  };
  if (lower.endsWith('.csv') || lower.endsWith('.txt')) reader.readAsText(file, 'utf-8');
  else reader.readAsDataURL(file);
}

function appendTokens(tokens) {
  if (!tokens || !tokens.length) return;
  const ta = $('batchText');
  const cur = ta.value.trim();
  ta.value = (cur ? cur + '\n' : '') + tokens.join('\n');
  toast(`已导入 ${tokens.length} 条`);
}

/* ================= 数据管理：上传新 Excel ================= */
const admin = { file: null, busy: false };

function openAdmin() {
  $('adminModal').hidden = false;
  adminMsg('');
  fetch('/api/admin/info').then((r) => r.json()).then((d) => {
    if (d.ok && !d.hasAdmin) {
      adminMsg('服务器尚未设置管理密码，网页上传功能已关闭。请在服务器的 config.json 中添加 "adminCode" 后重启服务。', 'err');
      $('adminUpload').disabled = true;
    }
  }).catch(() => {});
  setTimeout(() => $('adminCode').focus(), 120);
}

function closeAdmin() {
  $('adminModal').hidden = true;
  admin.file = null;
  $('adminFileName').textContent = '点击选择或拖拽 .xlsx 文件到此';
  $('adminDrop').classList.remove('has-file');
  $('adminFile').value = '';
  $('adminUpload').disabled = true;
  $('adminCode').value = '';
  adminMsg('');
}

function adminMsg(text, type) {
  const el = $('adminMsg');
  el.className = 'admin-msg' + (type ? ' ' + type : '');
  el.textContent = text || '';
}

function pickAdminFile(file) {
  if (!file) return;
  if (!/\.xlsx$/i.test(file.name)) {
    adminMsg('请选择 .xlsx 文件（旧版 .xls 请先另存为 .xlsx）', 'err');
    return;
  }
  admin.file = file;
  $('adminFileName').textContent = file.name + '（' + (file.size / 1024).toFixed(0) + ' KB）';
  $('adminDrop').classList.add('has-file');
  $('adminUpload').disabled = !$('adminCode').value.trim();
  adminMsg('');
}

async function doUpload() {
  if (!admin.file || admin.busy) return;
  const code = $('adminCode').value.trim();
  if (!code) { adminMsg('请输入管理密码', 'err'); return; }

  admin.busy = true;
  const btn = $('adminUpload');
  btn.disabled = true;
  const old = btn.textContent;
  btn.textContent = '上传中…';
  adminMsg('正在上传并校验数据…', 'info');

  try {
    const b64 = await new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(String(fr.result || '').split(',')[1] || '');
      fr.onerror = reject;
      fr.readAsDataURL(admin.file);
    });

    const res = await fetch('/api/admin/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ adminCode: code, fileName: admin.file.name, base64: b64 }),
    });
    if (res.status === 401) { location.replace('/login'); return; }
    const d = await res.json();

    if (!d.ok) {
      adminMsg(d.error || '上传失败', 'err');
      return;
    }

    const s = d.stats || {};
    const used = (d.sheets || []).filter((x) => x.used).map((x) => x.name + ' ' + x.rows + '条').join('、');
    let msg = `上传成功！已更新为 ${s.total || 0} 人 / ${s.dots || 0} 个点。`;
    msg += `\n红 ${(s.colors && s.colors.red) || 0} · 绿 ${(s.colors && s.colors.green) || 0} · 紫 ${(s.colors && s.colors.purple) || 0} · 黄 ${(s.colors && s.colors.yellow) || 0}`;
    if (used) msg += `\n数据来源：${used}`;
    if (d.backup) msg += `\n旧文件已备份为 ${d.backup}`;
    if (d.warnings && d.warnings.length) msg += `\n提示：${d.warnings.join('；')}`;
    msg += '\n所有在线用户会在 2 秒内自动看到新数据。';
    adminMsg(msg, 'ok');
    toast('数据已更新');

    state.hash = '';
    await fetchData(true);
    admin.file = null;
    $('adminFileName').textContent = '点击选择或拖拽 .xlsx 文件到此';
    $('adminDrop').classList.remove('has-file');
    $('adminFile').value = '';
  } catch (e) {
    adminMsg('上传失败：' + e.message, 'err');
  } finally {
    admin.busy = false;
    btn.textContent = old;
    btn.disabled = !admin.file;
  }
}

/* ================= 事件绑定 ================= */
function switchTab(tab) {
  document.querySelectorAll('.tab').forEach((x) => x.classList.toggle('active', x.dataset.tab === tab));
  state.tab = tab;
  const isAll = tab === 'all';
  $('viewAll').hidden = !isAll;
  $('viewBatch').hidden = isAll;
  $('allTools').style.display = isAll ? '' : 'none';
  if (history.replaceState) history.replaceState(null, '', isAll ? '#all' : '#batch');
}

function bind() {
  document.querySelectorAll('.tab').forEach((t) => {
    t.addEventListener('click', () => switchTab(t.dataset.tab));
  });

  if (location.hash === '#batch') switchTab('batch');

  $('searchInput').addEventListener('input', (e) => {
    state.q = e.target.value;
    renderTable();
  });

  $('chips').addEventListener('click', (e) => {
    const btn = e.target.closest('.chip');
    if (!btn) return;
    document.querySelectorAll('#chips .chip').forEach((c) => c.classList.remove('active'));
    btn.classList.add('active');
    state.filter = btn.dataset.filter;
    renderTable();
  });

  document.querySelectorAll('th.sortable').forEach((th) => {
    th.addEventListener('click', () => {
      const k = th.dataset.sort;
      if (state.sortKey === k) state.sortDir = -state.sortDir;
      else { state.sortKey = k; state.sortDir = 1; }
      renderTable();
    });
  });

  $('refreshBtn').addEventListener('click', async () => {
    const btn = $('refreshBtn');
    btn.classList.add('spin');
    await fetchData(true);
    setTimeout(() => btn.classList.remove('spin'), 500);
    toast('已刷新');
  });

  $('queryBtn').addEventListener('click', () => runQuery(false));
  $('clearBtn').addEventListener('click', () => {
    $('batchText').value = '';
    state.batchIds = [];
    state.batchRows = null;
    state.batchSummary = null;
    $('batchResult').hidden = true;
    $('batchEmpty').hidden = false;
  });

  $('fileInput').addEventListener('change', (e) => {
    handleFile(e.target.files[0]);
    e.target.value = '';
  });

  $('exportBtn').addEventListener('click', exportExcel);
  $('copyBtn').addEventListener('click', copyResult);

  // 拖拽到文本框
  const ta = $('batchText');
  ['dragover', 'dragenter'].forEach((ev) => ta.addEventListener(ev, (e) => { e.preventDefault(); }));
  ta.addEventListener('drop', (e) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
  });

  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      if (state.tab === 'batch') { e.preventDefault(); runQuery(false); }
    }
  });

  /* ---- 数据管理弹窗 ---- */
  $('adminBtn').addEventListener('click', openAdmin);
  $('adminClose').addEventListener('click', closeAdmin);
  $('adminCancel').addEventListener('click', closeAdmin);
  $('adminModal').addEventListener('click', (e) => {
    if (e.target === $('adminModal')) closeAdmin();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !$('adminModal').hidden) closeAdmin();
  });

  $('adminFile').addEventListener('change', (e) => pickAdminFile(e.target.files[0]));
  $('adminCode').addEventListener('input', () => {
    $('adminUpload').disabled = !admin.file || !$('adminCode').value.trim();
  });

  const drop = $('adminDrop');
  ['dragover', 'dragenter'].forEach((ev) =>
    drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); })
  );
  ['dragleave', 'drop'].forEach((ev) =>
    drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); })
  );
  drop.addEventListener('drop', (e) => {
    if (e.dataTransfer.files && e.dataTransfer.files[0]) pickAdminFile(e.dataTransfer.files[0]);
  });

  $('adminUpload').addEventListener('click', doUpload);
}

/* ================= 启动 ================= */
bind();
fetchData(false);
setInterval(() => fetchData(true), 2000);
