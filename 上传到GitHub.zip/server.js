'use strict';
/**
 * 文化周周边打卡查询 · 本地服务
 * - 实时读取 Excel（每次请求校验 mtime/size，文件一改页面自动更新）
 * - 同一工号/姓名的重复记录只计 1 个点（每色最多 1 个）
 * - 批量导入工号 → 批量导出结果 Excel
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { readWorkbook } = require('./lib/xlsx-read');
const { buildXlsx } = require('./lib/xlsx-write');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const START_PORT = Number(process.env.PORT || 4321);
const NO_OPEN = process.argv.includes('--no-open');

/* ================= 配置：访问码 ================= */
const CONFIG_FILE = path.join(ROOT, 'config.json');

function readConfig() {
  try {
    return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')) || {};
  } catch (_) {
    return {};
  }
}

const CONFIG = readConfig();
const ACCESS_CODE = String(process.env.ACCESS_CODE || CONFIG.accessCode || '').trim();
const AUTH_TOKEN = ACCESS_CODE
  ? crypto.createHash('sha256').update('cw-auth::' + ACCESS_CODE).digest('hex').slice(0, 40)
  : '';

// 经过内网穿透（Cloudflare / ngrok / cpolar 等）的请求一定带有转发头
function isExternal(req) {
  const h = req.headers;
  if (h['cf-connecting-ip'] || h['cf-ray'] || h['x-forwarded-for'] || h['x-real-ip']) return true;
  const ip = req.socket.remoteAddress || '';
  return !(ip === '' || ip === '::1' || ip === '127.0.0.1' || ip === '::ffff:127.0.0.1');
}

function isAuthed(req) {
  if (!ACCESS_CODE) return true;      // 未设置访问码 → 不拦截
  if (!isExternal(req)) return true;  // 本机访问 → 免密
  const m = /(?:^|;\s*)cw_auth=([^;]+)/.exec(req.headers.cookie || '');
  return !!m && m[1] === AUTH_TOKEN;
}

// 简易防爆破：同一 IP 10 分钟内最多 12 次失败
const loginFails = new Map();
// 真实客户端 IP（云服务器通常在 Nginx 后面，需读转发头）
function clientIp(req) {
  const xf = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  return xf || String(req.socket.remoteAddress || 'unknown');
}
function tooManyFails(ip) {
  const rec = loginFails.get(ip);
  if (!rec) return false;
  if (Date.now() - rec.first > 10 * 60 * 1000) { loginFails.delete(ip); return false; }
  return rec.count >= 12;
}
function noteFail(ip) {
  const rec = loginFails.get(ip);
  if (!rec || Date.now() - rec.first > 10 * 60 * 1000) loginFails.set(ip, { first: Date.now(), count: 1 });
  else rec.count++;
}

/* ================= 配置：数据文件 ================= */
function resolveExcelPath() {
  if (process.env.EXCEL_PATH) return path.resolve(process.env.EXCEL_PATH);
  const cfgFile = path.join(ROOT, 'config.json');
  if (fs.existsSync(cfgFile)) {
    try {
      const cfg = JSON.parse(fs.readFileSync(cfgFile, 'utf8'));
      if (cfg.excelPath) {
        return path.isAbsolute(cfg.excelPath) ? cfg.excelPath : path.resolve(ROOT, cfg.excelPath);
      }
    } catch (_) { /* 配置损坏则忽略 */ }
  }
  const preferred = path.join(ROOT, '文化周周边数据表.xlsx');
  if (fs.existsSync(preferred)) return preferred;
  const cands = fs.readdirSync(ROOT).filter((f) => /\.xlsx$/i.test(f) && !f.startsWith('~$'));
  return cands.length ? path.join(ROOT, cands[0]) : preferred;
}

/* ================= 颜色定义 ================= */
const COLORS = ['red', 'green', 'purple', 'yellow'];
const COLOR_LABEL = { red: '红点', green: '绿点', purple: '紫点', yellow: '黄点' };

const SHEET_RULES = [
  [/选修|elective/i, 'green'],
  [/必修|required|compulsory/i, 'red'],
  [/文化互动|互动|interaction/i, 'purple'],
  [/调查|问卷|survey|questionnaire/i, 'yellow'],
];
const COLOR_KEYWORDS = [
  [/绿|green/i, 'green'],
  [/红|red/i, 'red'],
  [/紫|purple|violet/i, 'purple'],
  [/黄|yellow/i, 'yellow'],
];

function matchBy(list, text) {
  if (!text) return null;
  for (const [re, val] of list) if (re.test(text)) return val;
  return null;
}

function normId(v) {
  return String(v == null ? '' : v).replace(/[\s'"]/g, '').toUpperCase();
}
function normName(v) {
  return String(v == null ? '' : v).replace(/\s+/g, ' ').trim();
}

/* ================= 解析 Excel → 人员数据 ================= */
function parsePeople(sheets) {
  const people = new Map(); // key -> person
  const sheetInfo = [];
  const warnings = [];

  const touch = (id, name) => {
    const key = id || 'NAME:' + name;
    let p = people.get(key);
    if (!p) {
      p = { key, id, name, colors: {}, sheets: [] };
      people.set(key, p);
    }
    if (!p.name && name) p.name = name;
    if (!p.id && id) p.id = id;
    return p;
  };

  for (const sheet of sheets) {
    const rows = sheet.rows || [];
    const sheetColor = matchBy(SHEET_RULES, sheet.name);

    // 定位表头
    let headerRow = -1;
    let cId = -1;
    let cName = -1;
    let cColor = -1;
    for (let r = 0; r < Math.min(rows.length, 10); r++) {
      const row = rows[r] || [];
      let id = -1, nm = -1, cl = -1;
      for (let c = 0; c < row.length; c++) {
        const t = normName(row[c]);
        if (id < 0 && /工号|员工编号|员工号|工號|编号|ID/i.test(t)) id = c;
        else if (nm < 0 && /姓名|名字|员工姓名|人名/i.test(t)) nm = c;
        else if (cl < 0 && /颜色|顏色|色|类别|标记/i.test(t)) cl = c;
      }
      if (id >= 0 || nm >= 0) { headerRow = r; cId = id; cName = nm; cColor = cl; break; }
    }
    if (headerRow < 0) {
      if (rows.some((r) => (r || []).some((v) => normName(v)))) {
        warnings.push('工作表「' + sheet.name + '」未找到「工号/姓名」表头，已跳过');
      }
      sheetInfo.push({ name: sheet.name, color: sheetColor, used: false, rows: 0, hasColorColumn: false });
      continue;
    }

    const hasColorColumn = cColor >= 0;
    if (!hasColorColumn && !sheetColor) {
      warnings.push('工作表「' + sheet.name + '」既没有「颜色」列，表名也无法识别颜色，已跳过');
      sheetInfo.push({ name: sheet.name, color: null, used: false, rows: 0, hasColorColumn: false });
      continue;
    }

    let used = 0;
    for (let r = headerRow + 1; r < rows.length; r++) {
      const row = rows[r] || [];
      const id = cId >= 0 ? normId(row[cId]) : '';
      const name = cName >= 0 ? normName(row[cName]) : '';
      if (!id && !name) continue;

      let color = null;
      if (hasColorColumn) {
        const cell = normName(row[cColor]);
        if (cell) color = matchBy(COLOR_KEYWORDS, cell) || sheetColor;
        else color = null; // 颜色列为空 = 该项未完成，不计点
      } else {
        color = sheetColor;
      }
      if (!color) continue;

      const p = touch(id, name);
      p.colors[color] = 1;
      if (!p.sheets.includes(sheet.name)) p.sheets.push(sheet.name);
      used++;
    }
    sheetInfo.push({
      name: sheet.name,
      color: sheetColor,
      used: true,
      rows: used,
      hasColorColumn,
    });
  }

  const list = [...people.values()].map((p) => {
    const colors = {};
    for (const c of COLORS) colors[c] = p.colors[c] ? 1 : 0;
    const count = COLORS.reduce((s, c) => s + colors[c], 0);
    return {
      id: p.id || '',
      name: p.name || '',
      colors,
      count,
      sheets: p.sheets,
      colorText: COLORS.filter((c) => colors[c]).map((c) => COLOR_LABEL[c]).join('、'),
    };
  });

  list.sort((a, b) => {
    const ai = a.id || 'zzz';
    const bi = b.id || 'zzz';
    return ai.localeCompare(bi, 'zh-CN', { numeric: true });
  });

  const stats = { total: list.length, colors: {}, dots: 0, dist: { 0: 0, 1: 0, 2: 0, 3: 0, 4: 0 } };
  for (const c of COLORS) stats.colors[c] = 0;
  for (const p of list) {
    for (const c of COLORS) if (p.colors[c]) stats.colors[c]++;
    stats.dots += p.count;
    stats.dist[p.count] = (stats.dist[p.count] || 0) + 1;
  }

  return { people: list, stats, sheets: sheetInfo, warnings };
}

/* ================= 缓存 ================= */
const cache = {
  path: null,
  mtimeMs: 0,
  size: -1,
  payload: null,
  error: null,
  loadedAt: 0,
};

function loadData(force) {
  const file = resolveExcelPath();
  let st;
  try {
    st = fs.statSync(file);
  } catch (e) {
    return {
      ok: false,
      error: '找不到数据文件：' + file,
      filePath: file,
      fileName: path.basename(file),
      payload: cache.payload,
    };
  }

  if (!force && cache.payload && cache.path === file && cache.mtimeMs === st.mtimeMs && cache.size === st.size) {
    return { ok: true, ...cache.payload, error: cache.error };
  }

  let buf = null;
  let lastErr = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      buf = fs.readFileSync(file);
      break;
    } catch (e) {
      lastErr = e;
      // Excel 正在保存时可能短暂占用文件
      const end = Date.now() + 120;
      while (Date.now() < end) { /* 短暂等待 */ }
    }
  }
  if (!buf) {
    return {
      ok: false,
      error: '读取 Excel 失败（可能正被 Excel 占用）：' + (lastErr && lastErr.message),
      filePath: file,
      fileName: path.basename(file),
      payload: cache.payload,
    };
  }

  try {
    const wb = readWorkbook(buf);
    const parsed = parsePeople(wb.sheets);
    const hash = crypto.createHash('md5')
      .update(JSON.stringify(parsed.people) + JSON.stringify(parsed.stats))
      .digest('hex');

    const payload = {
      hash,
      filePath: file,
      fileName: path.basename(file),
      updatedAt: new Date(st.mtimeMs).toISOString(),
      fileSize: st.size,
      ...parsed,
    };
    cache.path = file;
    cache.mtimeMs = st.mtimeMs;
    cache.size = st.size;
    cache.payload = payload;
    cache.error = null;
    cache.loadedAt = Date.now();
    return { ok: true, ...payload };
  } catch (e) {
    return {
      ok: false,
      error: '解析 Excel 失败：' + e.message,
      filePath: file,
      fileName: path.basename(file),
      payload: cache.payload,
    };
  }
}

/* ================= 批量匹配 ================= */
function buildIndex(people) {
  const byId = new Map();
  const byName = new Map();
  for (const p of people) {
    if (p.id) byId.set(normId(p.id), p);
    if (p.name && !byName.has(p.name)) byName.set(p.name, p);
  }
  return { byId, byName };
}

function splitTokens(text) {
  if (!text) return [];
  return String(text)
    .split(/[\s,，、;；|]+/)
    .map((t) => t.replace(/^["']|["']$/g, '').trim())
    .filter(Boolean);
}

function queryIds(people, rawIds) {
  const { byId, byName } = buildIndex(people);
  const seen = new Set();
  const rows = [];
  let dup = 0;

  for (const raw of rawIds) {
    const token = String(raw == null ? '' : raw).trim();
    if (!token) continue;
    const key = normId(token) || token;
    if (seen.has(key)) { dup++; continue; }
    seen.add(key);

    let p = byId.get(normId(token));
    let matchedBy = '工号';
    if (!p) {
      p = byName.get(normName(token));
      matchedBy = '姓名';
    }
    if (p) {
      rows.push({
        input: token,
        found: true,
        matchedBy,
        id: p.id,
        name: p.name,
        colors: p.colors,
        count: p.count,
        colorText: p.colorText,
      });
    } else {
      rows.push({
        input: token,
        found: false,
        matchedBy: '',
        id: normId(token),
        name: '',
        colors: { red: 0, green: 0, purple: 0, yellow: 0 },
        count: 0,
        colorText: '',
      });
    }
  }

  const found = rows.filter((r) => r.found);
  const summary = {
    input: rawIds.filter((x) => String(x || '').trim()).length,
    unique: rows.length,
    duplicate: dup,
    found: found.length,
    notFound: rows.length - found.length,
    colors: {},
    dots: 0,
  };
  for (const c of COLORS) summary.colors[c] = found.filter((r) => r.colors[c]).length;
  summary.dots = found.reduce((s, r) => s + r.count, 0);

  return { rows, summary };
}

/* ================= 导出 Excel ================= */
function buildExport(people, rawIds) {
  const { rows, summary } = queryIds(people, rawIds);

  const header = ['工号', '姓名', '红点', '绿点', '紫点', '黄点', '点数合计', '颜色汇总', '匹配状态', '导入内容'];
  const body = rows.map((r) => [
    r.id,
    r.name,
    r.colors.red,
    r.colors.green,
    r.colors.purple,
    r.colors.yellow,
    r.count,
    r.colorText || '—',
    r.found ? '已找到' : '未找到',
    r.input,
  ]);

  const now = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  const stamp = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}`;

  const detail = [
    header,
    ...body,
  ];

  const statRows = [
    ['项目', '数量'],
    ['导入条数', summary.input],
    ['去重后', summary.unique],
    ['重复剔除', summary.duplicate],
    ['已找到', summary.found],
    ['未找到', summary.notFound],
    ['红点人数', summary.colors.red],
    ['绿点人数', summary.colors.green],
    ['紫点人数', summary.colors.purple],
    ['黄点人数', summary.colors.yellow],
    ['总点数', summary.dots],
    ['导出时间', `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`],
  ];

  const buf = buildXlsx([
    {
      name: '查询结果',
      rows: detail,
      widths: [16, 18, 7, 7, 7, 7, 10, 18, 10, 16],
    },
    {
      name: '统计汇总',
      rows: statRows,
      widths: [16, 24],
    },
  ]);

  return { buf, rows, summary, fileName: `文化周周边查询结果_${stamp}.xlsx` };
}

/* ================= HTTP ================= */
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
};

function sendJson(res, code, obj) {
  const body = Buffer.from(JSON.stringify(obj), 'utf8');
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': body.length,
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

function readBody(req, limit = 32 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new Error('请求体过大')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

async function readJson(req) {
  const buf = await readBody(req);
  if (!buf.length) return {};
  return JSON.parse(buf.toString('utf8'));
}

function serveStatic(req, res, urlPath) {
  let rel = decodeURIComponent(urlPath.split('?')[0]);
  if (rel === '/' || rel === '') rel = '/index.html';
  const file = path.join(PUBLIC_DIR, path.normalize(rel).replace(/^(\.\.[/\\])+/, ''));
  if (!file.startsWith(PUBLIC_DIR)) { res.writeHead(403); res.end('Forbidden'); return; }
  fs.readFile(file, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('404 Not Found');
      return;
    }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': 'no-store',
    });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const p = url.pathname;

  try {
    /* ---- 登录 / 访问码 ---- */
    if (p === '/api/login' && req.method === 'POST') {
      const ip = clientIp(req);
      if (tooManyFails(ip)) {
        sendJson(res, 429, { ok: false, error: '尝试次数过多，请 10 分钟后再试' });
        return;
      }
      const body = await readJson(req);
      const code = String(body.code || '').trim();
      if (!ACCESS_CODE) { sendJson(res, 200, { ok: true }); return; }
      if (code && code === ACCESS_CODE) {
        loginFails.delete(ip);
        res.writeHead(200, {
          'Content-Type': 'application/json; charset=utf-8',
          'Set-Cookie': 'cw_auth=' + AUTH_TOKEN + '; Path=/; Max-Age=2592000; HttpOnly; SameSite=Lax',
          'Cache-Control': 'no-store',
        });
        res.end(JSON.stringify({ ok: true }));
        return;
      }
      noteFail(ip);
      sendJson(res, 200, { ok: false, error: '访问码不正确' });
      return;
    }

    if (p === '/login' || p === '/login.html') {
      serveStatic(req, res, '/login.html');
      return;
    }

    if (!isAuthed(req)) {
      if (p.startsWith('/api/')) {
        sendJson(res, 401, { ok: false, error: '需要访问码', needLogin: true });
      } else {
        res.writeHead(302, { Location: '/login' });
        res.end();
      }
      return;
    }

    if (p === '/api/data') {
      const since = url.searchParams.get('since') || '';
      const d = loadData(false);
      if (!d.ok && !d.payload) {
        sendJson(res, 200, { ok: false, error: d.error, filePath: d.filePath, fileName: d.fileName });
        return;
      }
      const payload = d.ok ? d : { ...d.payload, staleError: d.error };
      if (since && payload.hash === since) {
        sendJson(res, 200, { ok: true, changed: false, hash: payload.hash, error: d.error || null });
        return;
      }
      sendJson(res, 200, {
        ok: true,
        changed: true,
        hash: payload.hash,
        filePath: payload.filePath,
        fileName: payload.fileName,
        updatedAt: payload.updatedAt,
        serverTime: Date.now(),
        people: payload.people,
        stats: payload.stats,
        sheets: payload.sheets,
        warnings: payload.warnings || [],
        error: d.error || null,
      });
      return;
    }

    if (p === '/api/query' && req.method === 'POST') {
      const body = await readJson(req);
      const d = loadData(false);
      if (!d.ok && !d.payload) { sendJson(res, 200, { ok: false, error: d.error }); return; }
      const data = d.ok ? d : d.payload;
      const ids = Array.isArray(body.ids) ? body.ids : splitTokens(body.text);
      const result = queryIds(data.people, ids);
      sendJson(res, 200, { ok: true, ...result, hash: data.hash });
      return;
    }

    if (p === '/api/export' && req.method === 'POST') {
      const body = await readJson(req);
      const d = loadData(false);
      if (!d.ok && !d.payload) { sendJson(res, 200, { ok: false, error: d.error }); return; }
      const data = d.ok ? d : d.payload;
      const ids = Array.isArray(body.ids) ? body.ids : splitTokens(body.text);
      if (!ids.length) { sendJson(res, 400, { ok: false, error: '没有可导出的工号' }); return; }
      const { buf, fileName } = buildExport(data.people, ids);
      res.writeHead(200, {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Length': buf.length,
        'Content-Disposition': "attachment; filename=\"result.xlsx\"; filename*=UTF-8''" + encodeURIComponent(fileName),
        'Cache-Control': 'no-store',
      });
      res.end(buf);
      return;
    }

    // 从上传的文件里提取工号（xlsx 在服务端解析）
    if (p === '/api/extract' && req.method === 'POST') {
      const body = await readJson(req);
      const name = String(body.name || '');
      const b64 = String(body.base64 || '').replace(/^data:[^;]+;base64,/, '');
      if (!b64) { sendJson(res, 400, { ok: false, error: '文件为空' }); return; }
      const buf = Buffer.from(b64, 'base64');

      let tokens = [];
      if (/\.xlsx$/i.test(name)) {
        const wb = readWorkbook(buf);
        const d = loadData(false);
        const known = new Set();
        if (d.payload) {
          for (const person of d.payload.people) {
            if (person.id) known.add(normId(person.id));
            if (person.name) known.add(person.name);
          }
        }
        const cells = [];
        for (const sheet of wb.sheets) {
          for (const row of sheet.rows) {
            for (const cell of row || []) {
              const t = normName(cell);
              if (t) cells.push(t);
            }
          }
        }
        const idLike = cells.filter((t) => /[0-9]/.test(t) && /^[A-Za-z0-9\-_.]{3,}$/.test(t));
        const pool = idLike.length ? idLike : cells;
        const seen = new Set();
        for (const t of pool) {
          if (/^(工号|姓名|颜色|红点|绿点|紫点|黄点|序号|编号)$/.test(t)) continue;
          const k = normId(t) || t;
          if (seen.has(k)) continue;
          seen.add(k);
          tokens.push(t);
        }
        if (known.size) {
          const strict = tokens.filter((t) => known.has(normId(t)) || known.has(t));
          if (strict.length) tokens = strict;
        }
      } else {
        tokens = splitTokens(buf.toString('utf8'));
      }

      sendJson(res, 200, { ok: true, tokens, count: tokens.length });
      return;
    }

    if (p === '/api/health') {
      const d = loadData(false);
      sendJson(res, 200, { ok: !!d.ok, filePath: resolveExcelPath(), error: d.error || null });
      return;
    }

    /* ---- 管理：网页上传新 Excel（上传即生效，自动备份 + 校验回滚） ---- */
    if (p === '/api/admin/info') {
      const cfgNow = readConfig();
      sendJson(res, 200, {
        ok: true,
        hasAdmin: !!String(process.env.ADMIN_CODE || cfgNow.adminCode || '').trim(),
        excelPath: resolveExcelPath(),
        fileName: path.basename(resolveExcelPath()),
        allowRemoteUpload: cfgNow.allowRemoteUpload !== false,
        service: String(cfgNow.serviceName || '文化周周边打卡查询'),
      });
      return;
    }

    if (p === '/api/admin/upload' && req.method === 'POST') {
      const cfgNow = readConfig();
      const ADMIN_CODE = String(process.env.ADMIN_CODE || cfgNow.adminCode || '').trim();

      if (!ADMIN_CODE) {
        sendJson(res, 403, { ok: false, error: '服务器未设置管理密码，网页上传已关闭。请在 config.json 中设置 adminCode。' });
        return;
      }
      // 仅允许本机或同局域网上传（可关闭）
      if (cfgNow.allowRemoteUpload === false && isExternal(req)) {
        sendJson(res, 403, { ok: false, error: '服务器已禁用远程上传，请登录服务器替换文件。' });
        return;
      }

      const ip = clientIp(req);
      if (tooManyFails('admin:' + ip)) {
        sendJson(res, 429, { ok: false, error: '尝试次数过多，请 10 分钟后再试' });
        return;
      }

      const body = await readJson(req);
      if (String(body.adminCode || '').trim() !== ADMIN_CODE) {
        noteFail('admin:' + ip);
        sendJson(res, 200, { ok: false, error: '管理密码不正确' });
        return;
      }
      loginFails.delete('admin:' + ip);

      const b64 = String(body.base64 || '').replace(/^data:[^;]+;base64,/, '');
      if (!b64) { sendJson(res, 400, { ok: false, error: '没有收到文件内容' }); return; }
      const buf = Buffer.from(b64, 'base64');
      if (buf.length < 100) { sendJson(res, 400, { ok: false, error: '文件太小，可能不是有效的 xlsx' }); return; }
      if (!(buf[0] === 0x50 && buf[1] === 0x4b)) {
        sendJson(res, 400, { ok: false, error: '不是有效的 .xlsx 文件（旧版 .xls 请先另存为 .xlsx）' });
        return;
      }

      // 1) 先解析校验，避免坏文件覆盖好数据
      let parsedNew;
      try {
        const wbNew = readWorkbook(buf);
        parsedNew = parsePeople(wbNew.sheets);
      } catch (e) {
        sendJson(res, 400, { ok: false, error: '解析失败，文件可能已损坏：' + e.message });
        return;
      }
      if (!parsedNew.people.length) {
        sendJson(res, 400, { ok: false, error: '新文件里没有解析到任何人员数据，已拒绝覆盖。请检查表头是否为「工号/姓名/颜色」。' });
        return;
      }

      // 2) 备份旧文件
      const target = resolveExcelPath();
      let backupPath = null;
      try {
        if (fs.existsSync(target)) {
          const st = new Date();
          const pad = (n) => String(n).padStart(2, '0');
          const stamp = `${st.getFullYear()}${pad(st.getMonth() + 1)}${pad(st.getDate())}_${pad(st.getHours())}${pad(st.getMinutes())}${pad(st.getSeconds())}`;
          backupPath = path.join(path.dirname(target), 'backup_' + stamp + '.xlsx');
          fs.copyFileSync(target, backupPath);
          // 只保留最近 20 个备份
          const dir = path.dirname(target);
          const olds = fs.readdirSync(dir)
            .filter((f) => /^backup_\d{8}_\d{6}\.xlsx$/.test(f))
            .sort()
            .reverse();
          for (const old of olds.slice(20)) {
            try { fs.unlinkSync(path.join(dir, old)); } catch (_) {}
          }
        }
      } catch (e) {
        backupPath = null; // 备份失败不阻断，但下面要提示
      }

      // 3) 写入并清缓存（下次请求即读到新数据）
      try {
        fs.writeFileSync(target, buf);
        cache.mtimeMs = 0;
        cache.payload = null;
      } catch (e) {
        sendJson(res, 500, { ok: false, error: '写入文件失败：' + e.message });
        return;
      }

      // 4) 回读确认
      const after = loadData(true);
      if (!after.ok) {
        if (backupPath) { try { fs.copyFileSync(backupPath, target); cache.payload = null; } catch (_) {} }
        sendJson(res, 500, { ok: false, error: '新数据回读失败，已回滚：' + (after.error || '') });
        return;
      }

      sendJson(res, 200, {
        ok: true,
        fileName: path.basename(target),
        backup: backupPath ? path.basename(backupPath) : null,
        stats: after.stats,
        sheets: after.sheets,
        warnings: after.warnings || [],
      });
      return;
    }

    if (p === '/favicon.ico') { res.writeHead(204); res.end(); return; }

    serveStatic(req, res, p);
  } catch (e) {
    sendJson(res, 500, { ok: false, error: e.message });
  }
});

/* ================= 启动 ================= */
function lanIPs() {
  const out = [];
  const nets = os.networkInterfaces();
  for (const k of Object.keys(nets)) {
    for (const n of nets[k] || []) {
      if (n.family !== 'IPv4' || n.internal) continue;
      const m = /^(\d+)\.(\d+)\./.exec(n.address);
      if (!m) continue;
      const a = +m[1];
      const b = +m[2];
      const priv = a === 10 || (a === 192 && b === 168) || (a === 172 && b >= 16 && b <= 31);
      if (priv) out.push(n.address);
    }
  }
  return out;
}

function openBrowser(url) {
  const { exec } = require('child_process');
  if (process.platform === 'win32') exec(`start "" "${url}"`, { shell: 'cmd.exe' });
  else if (process.platform === 'darwin') exec(`open "${url}"`);
  else exec(`xdg-open "${url}"`);
}

function listen(port, tries) {
  server.once('error', (e) => {
    if (e.code === 'EADDRINUSE' && tries > 0) {
      listen(port + 1, tries - 1);
    } else {
      console.error('启动失败：', e.message);
      process.exit(1);
    }
  });
  server.listen(port, '0.0.0.0', () => {
    const url = 'http://127.0.0.1:' + port;
    const file = resolveExcelPath();
    const d = loadData(true);
    console.log('');
    console.log('  文化周周边打卡查询 · 已启动');
    console.log('  ------------------------------------------');
    console.log('  本机访问 : ' + url);
    for (const ip of lanIPs()) console.log('  局域网   : http://' + ip + ':' + port);
    console.log('  数据文件 : ' + file);
    if (ACCESS_CODE) {
      console.log('  访问码   : ' + ACCESS_CODE + '  （非本机访问需输入）');
    } else {
      console.log('  访问码   : 未设置（任何能连上的人都能打开）');
    }
    if (d.ok) {
      console.log('  解析结果 : ' + d.stats.total + ' 人 / ' + d.stats.dots + ' 个点');
    } else {
      console.log('  [警告] ' + d.error);
    }
    console.log('  ------------------------------------------');
    console.log('  关闭此窗口即停止服务');
    console.log('');
    if (!NO_OPEN) openBrowser(url);
  });
}

listen(START_PORT, 12);

/* ================= 守护：单次异常不退出 ================= */
process.on('uncaughtException', (e) => {
  console.error('[未捕获异常] ' + (e && e.stack ? e.stack : e));
});
process.on('unhandledRejection', (e) => {
  console.error('[未处理的 Promise 拒绝] ' + (e && e.stack ? e.stack : e));
});

